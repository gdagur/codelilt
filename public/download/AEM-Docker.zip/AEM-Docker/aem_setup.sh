#!/bin/bash

trap 'exit' ERR

#Install Java
yum install java-1.8.0-openjdk -y

#Set Java Exports
touch /etc/profile.d/java.sh
JAVA_HOME_LINK=`readlink -f /usr/bin/java`
JAVA_HOME=`echo $JAVA_HOME_LINK | cut -d'/' -f-5`
echo -e "export JAVA_HOME=$JAVA_HOME PATH=$JAVA_HOME/bin:$PATH" > /etc/profile.d/java.sh

#Unpack AEM JAR
java -Djava.awt.headless=true -XX:MaxPermSize=256m -Xmx1280m -jar cq-author-4502.jar -unpack

#Copy pacakges to install folder
cp -R /opt/aem/packages/. /opt/aem/crx-quickstart/install/


#set heap and runmode settings
sed  -i "s/CQ_RUNMODE='author'/CQ_RUNMODE='nosamplecontent,author'/g" /opt/aem/crx-quickstart/bin/start
sed  -i "s/#CQ_RUNMODE=''/CQ_RUNMODE='nosamplecontent,author'/g" /opt/aem/crx-quickstart/bin/quickstart
sed  -i "s/CQ_JVM_OPTS='-server -Xmx1024m -XX:MaxPermSize=256M'/CQ_JVM_OPTS='-server -Xmx2048m -XX:MaxPermSize=1024M'/g" /opt/aem/crx-quickstart/bin/quickstart
sed  -i "s/CQ_JVM_OPTS='-server -Xmx1024m -XX:MaxPermSize=256M -Djava.awt.headless=true'/CQ_JVM_OPTS='-server -Xmx2048m -XX:MaxPermSize=1024M -Djava.awt.headless=true'/g" /opt/aem/crx-quickstart/bin/start

exec "$@"
