#!/bin/bash

# Start AEM server
/opt/aem/crx-quickstart/bin/start
#tail logs
tail -f /opt/aem/crx-quickstart/logs/*

