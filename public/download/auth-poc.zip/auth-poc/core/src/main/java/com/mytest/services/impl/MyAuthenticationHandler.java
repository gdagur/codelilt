package com.mytest.services.impl;
import java.io.IOException;

import javax.jcr.SimpleCredentials;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.auth.core.AuthUtil;
import org.apache.sling.auth.core.spi.AuthenticationFeedbackHandler;
import org.apache.sling.auth.core.spi.AuthenticationHandler;
import org.apache.sling.auth.core.spi.AuthenticationInfo;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(label = "My Token Authentication Handler", description = "My Token Authentication Handler", metatype = true, immediate = false)
@Properties({
		@Property(label = "Paths", description = "Paths which this handler will authenticate", name = AuthenticationHandler.PATH_PROPERTY, value = {"/"}, cardinality = 10),
		@Property(label = "Service Ranking", description = "Service ranking", name = "service.ranking", intValue = 5000, propertyPrivate = false),
		@Property(label = "Vendor", name = "service.vendor", value = "Auth poc", propertyPrivate = true)})
@Service
public class MyAuthenticationHandler
		implements
			AuthenticationHandler,
			AuthenticationFeedbackHandler {

	private final Logger log = LoggerFactory.getLogger(this.getClass()
			.getName());

	@Override
	public AuthenticationInfo extractCredentials(HttpServletRequest request,
			HttpServletResponse response) {
		AuthenticationInfo authInfo = null;
			if ("POST".equals(request.getMethod())   
					&& request.getRequestURI().endsWith("/j_security_check")
					&& request.getParameter("uname") != null
					&& request.getParameter("pass") != null) {
	
				if (!AuthUtil.isValidateRequest(request)) {
					AuthUtil.setLoginResourceAttribute(request,
							request.getContextPath());
				}
				SimpleCredentials creds = new SimpleCredentials(request.getParameter("uname"), request.getParameter("pass").toCharArray());
				authInfo = new AuthenticationInfo("TestAuth");
				authInfo.put(JcrResourceConstants.AUTHENTICATION_INFO_CREDENTIALS, creds);
				authInfo.put("user.name", request.getParameter("uname"));
			}
		return authInfo;
	}

	@Override
	public void dropCredentials(HttpServletRequest request,
			HttpServletResponse response) {	
	}

	@Override
	public boolean requestCredentials(HttpServletRequest request,
			HttpServletResponse response) {

		return false;
	}

	@Override
	public void authenticationFailed(HttpServletRequest request,
			HttpServletResponse response, AuthenticationInfo authInfo) {

		log.error("Authentication failed");
	}

	@Override
	public boolean authenticationSucceeded(HttpServletRequest request,
			HttpServletResponse response, AuthenticationInfo authInfo) {

		try {
			response.sendRedirect("/content/myauth/demo.html");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
}